# "C:\Program Files (x86)\Python351\Python.exe" "C:\Program Files (x86)\Python351\Projects\Name Generator\name_generator.py"

import os
import random
import sys

def getScriptPath():
	""" Returns current path of script """
	return os.path.dirname(os.path.realpath(sys.argv[0]))

input_dir = getScriptPath() + "\\input"
output_dir = getScriptPath() + "\\output"

GEN_AMOUNT = 1000
GEN_MINIMUM_LENGTH = 2
GEN_MAXIMUM_LENGTH = 3
GEN_FEMALE_CHANCE = 10

def main():
	os.chdir( input_dir )
	
	# Search input directory for segment lists
	for folderName, subFolders, filenameList in os.walk( input_dir ):	
			# For each list, get the name and then generate the names from the list
			for j in range( len( filenameList ) ):
				filename = filenameList[j]
				
				# Get name to use for save file
				splitString = filename.split( "_" )
				name = splitString[0]

				generateNames( filename, name )

def generateNames( filename, savename ):
	""" Generates a list of names from a list of segments """
	
	# Grab list of segments from file
	with open( filename, "rt" ) as sourceFile:
		text = sourceFile.readlines()
		
	# Create list of segments
	segmentList = []
	for i in range( len( text ) ):
		segmentList.append( text[i] )
	
	# End function if namelist is empty
	if len( segmentList ) <= 0:
		return
		
	# Create duplicate name list
	additionsList = []
		
	# Create output file
	os.chdir( output_dir )
	cultureNames = open( "{0}_culture.txt".format( savename ), "wt" )
	monarchNames = open( "{0}_monarch.txt".format( savename ), "wt" )
	leaderNames = open( "{0}_leader.txt".format( savename ), "wt" )
	os.chdir( input_dir )
	
	# Create names
	for i in range( GEN_AMOUNT ):
		length = random.randint( GEN_MINIMUM_LENGTH, GEN_MAXIMUM_LENGTH )
		
		nameList = []
		
		for j in range( length ):
			# Get random segment
			segment = segmentList[random.randint( 0, len( segmentList )-1 )]
			segment = segment.strip( "\n" )
			if j == 0:
				# First segment
				nameList.append( "\"{0}".format( segment.capitalize() ) )
			elif j == (length-1):
				# Last segment
				if savename == "demon":
					if random.randint( 0, 100 ) < 25:
						nameList.append( "'{0}\"".format( segment ) )
					else:
						nameList.append( "{0}\"".format( segment ) )
				else:
					nameList.append( "{0}\"".format( segment ) )
			else:
				# Other segments
				if savename == "demon":
					if random.randint( 0, 100 ) < 25:
						nameList.append( "'{0}".format(segment) )
					else:
						nameList.append( "{0}".format(segment) )
				else:
					nameList.append( "{0}".format(segment) )
			
		name = "".join( nameList )
		
		# Check if the name has already been made
		if name in additionsList:
			#print( "Duplicate name" )
			i = i - 1
		else:	
			additionsList.append( name )
		
		#print( nameList )
		#print( name )

		# Culture
		cultureNames.write( "{0} ".format( name ) )
		
		# Monarch
		if random.randint( 0, 100 ) > GEN_FEMALE_CHANCE:
			# Make male
			monarchNames.write( "\t{0} = 20\n".format( name ) )
		else:
			# Make female
			monarchNames.write( "\t{0} = -20\n".format( name ) )
		
		# Leader
		leaderNames.write( "\t{0}\n".format( name ) )
if __name__ == "__main__":
	main()